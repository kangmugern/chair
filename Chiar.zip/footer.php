<footer>
            <div class="center">
                <div class="footer1">
                    <div class="f_logo ">
                        <img src="img/logo_footer.png" alt="f_logo">
                    </div>
                    <div class="info ">
                        <ul>
                            <li><a href="#">Address: 99-4 ,  Gahyeonro 85-gil, <br> Tongjin, Gimpo, Gyeonggi, Korea</a></li>
                            <li><a href="#">Tel : +82-31-982-3915</a></li>
                            <li><a href="#" class="email">E-Mail : paul@winwincm.com</a></li>
                            <li><a href="#">Business Registration Number :<br> 132-86-21927</a></li>
                            <li><a href="#">Copyright (c) 2021 Chair Meister ALL Rights Reserved.</a></li>
                        </ul>
                    </div>
                </div>
                <div class="footer2">
                    <div class="family_site">
                        <a href="#">패밀리 사이트</a>
                        <div class="family_list">
                            <ul>
                                <li><a href="#">Family Site1</a></li>
                                <li><a href="#">Family Site2</a></li>
                                <li><a href="#">Family Site3</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="sns ">
                        <ul>
                            <li><a href="#">
                                <img src="img/youtube.png" alt="yotube">
                            </a></li>
                            <li><a href="#">
                                <img src="img/naver.png" alt="naver">
                            </a></li> 
                            <li><a href="#">
                                <img src="img/facebook.png" alt="facebook">
                            </a></li>
                            <li><a href="#">
                             <img src="img/insta.png" alt="insta">
                            </a></li>                                                                     
                        </ul>
                     </div>
                </div>
            </div>
        </footer>