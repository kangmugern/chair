<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <!-- 미디어쿼리 -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0 ,maximum-scale=1.0,minimum-scale=1.0">
    <title>체어마이스터</title>
    <!-- 파비콘 -->
    <link rel="shortcut icon" href="img/favicon.png">
    <!-- swiper.css cdn 으로 연결 -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@10/swiper-bundle.min.css"/>
    <script src="https://cdn.jsdelivr.net/npm/swiper@10/swiper-bundle.min.js"></script>
    <!-- 사용자 정의 css 연결 -->
    <link rel="stylesheet" href="css/main.css" type="text/css">
    <!-- 제이쿼리 라이브러리 연걸 -->
    <script src="js/jquery-3.7.1.js"></script>
    <!-- swiper js 파일을 cdn 으로 연동 -->
    <script src="https://cdn.jsdelivr.net/npm/swiper@10/swiper-bundle.min.js"></script>
    <!-- gsap 플러그인 연결 -->
    <script src="js/gsap.min.js"></script>
    <!-- 사용자 정의 제이쿼리 파일 연동 -->
    <script src="js/main.js"></script>
</head>
<body>
    <div class="wrap">
        <!-- header include -->
        <?php include "header.php"; ?>
        <section class="sec1">
        <!-- 메인 슬라이드 - swiper plugin -->
            <div class="swiper main">
                <!-- Additional required wrapper -->
                <div class="swiper-wrapper">
                <!-- Slides -->
                        <div class="swiper-slide s1">
                            <h2>Good <b>Design</b> </h2>                            
                            <p>Companies making standards for
                            <br>Office furniture in the world</p>
                            <a href="#"><img src="img/scroll.png" alt="#" class="scroll"></a>
                        </div>
                        <div class="swiper-slide s2">
                            <h2>Good <b>Design</b> </h2>
                            <p>Companies making standards for
                            <br>Office furniture in the world</p>
                            <a href="#"><img src="img/scroll.png" alt="#" class="scroll"></a>
                        </div>
                        <div class="swiper-slide s3">
                            <h2>Good <b>Design</b> </h2>
                            <p>Companies making standards for
                            <br>Office furniture in the world</p>
                            <a href="#"><img src="img/scroll.png" alt="#" class="scroll"></a>
                        </div>
                    </div>
                    <!-- 페이징 필요시 추가 -->
                    <div class="swiper-pagination"></div>
                </div>
           
        </section>
        <section class="sec2 scrollSet">
            <div class="center">
                <div class="chair ani firstAni">
                    <h2>CHAIRS</h2>
                    <b>READ MORE
                        <img src="img/arrow.png" alt="arrow" class="arrow">
                    </b>
                </div>
                <div class="com ani secondAni">
                    <h2>COMPONENTS</h2>
                    <b>READ MORE
                        <img src="img/arrow.png" alt="arrow" class="arrow">
                    </b>
                </div>
            </div>
        </section>
        <section class="sec3 scrollSet">
            <div class="center">
                <div class="content ani firstAni">
                    <h2>체어마이스터의 새로운 소식을<br> 전해 드립니다.</h2>
                    <button>
                        <a href="#">자세히 보기 ></a>
                    </button>
                </div>
                <!-- swiper slide -->
                <div class="swiper news ani secondAni">
                    <div class="swiper-wrapper">
                        <div class="swiper-slide">
                            <div class="image img1"></div>
                            <h2>디자인·필라소피</h2>
                            <p>체어마이스터를 만나보세요</p>
                        </div>
                        <div class="swiper-slide">
                            <div class="image img2"></div>
                            <h2>생산 및 테스트 설비</h2>
                            <p>다양한 제품을 확인하세요</p>
                        </div>
                        <div class="swiper-slide">
                            <div class="image img3"></div>
                            <h2>고객 상담 안내</h2>
                            <p>간편하고 손쉽게 As를 받으세요</p>
                        </div>
                        <div class="swiper-slide">
                            <div class="image img4"></div>
                            <h2>해외방람회</h2>
                            <p>해외로 진출하는 마이스터</p>
                        </div>
                        <div class="swiper-slide">
                            <div class="image img5"></div>
                            <h2>해외 오프라인 매장 </h2>
                            <p>오프라인 매장을 찾아보세요!</p>
                        </div>
                    </div>
                    <!-- swiper wrapper -->    
                    <!-- pagination progress -->
                    <div class="swiper-pagination"></div>
                </div>
                <div class="swiper-button-next ani firstAni"></div>
                <div class="swiper-button-prev ani firstAni"></div>
            </div>
        </section>
        <section class="sec4 scrollSet">
            <div class="center">
                <div class="exhi ani firstAni">
                    <h1>exhibition</h1>
                <!-- swiper slide -->
                    <div class="swiper exhibition">
                        <div class="swiper-wrapper">
                            <div class="swiper-slide">
                                <div class="image i1"></div>
                                <h2>CHAIR MEISTER GERMANY orgatec 2016</h2>
                                <p>2202-05-17</p>
                            </div>
                            <div class="swiper-slide">
                                <div class="image i2"></div>
                                <h2>CHAIR MEISTER GERMANY 2020</h2>
                                <p>2202-05-17</p>
                            </div>
                            <div class="swiper-slide">
                                <div class="image i3"></div>
                                <h2>CHAIR MEISTER KOFURN 2019</h2>
                                <p>2202-05-17</p>
                            </div>
                            <div class="swiper-slide">
                                <div class="image i4"></div>
                                <h2>CHAIR MEISTER INDEX 2017</h2>
                                <p>2202-05-17</p>
                            </div>
                        </div>
                        <!-- swiper wrapper -->                    
                        <!-- pagination progress -->
                        <div class="swiper-pagination"></div>
                        <div class="swiper-button-next"></div>
                        <div class="swiper-button-prev"></div>
                    </div>
                </div>
                <div class="content ani secondAni">
                    <h1>PRESS RELEASE</h1>            
                    <div class="box">
                        <h2>체어마이스터 '튤립' ,조달청<br><b>우수조달물품 지정</b></h2>
                        <p>체어마이스터'튤립',조달청<br><h3>우수조달물품 지정이넷 뉴스</h3></p>
                        <i>2023.07.05</i>
                    </div>
                </div>
            </div>
        </section>
        <section class="sec5 scrollSet ">
            <div class="center">
                <div class="content ani firstAni">
                    <h2>Introduce</h2>
                    <div class="component">
                        <img src="img/component.png" alt="component">
                    </div>
                </div>
                <div class="statis ani secondAni">
                    <ul>
                        <li>
                            <img src="img/person.png" alt="person">
                            <p>방문객</p>
                            <div class="number">
                                <span class="timer count-title count-number" data-to="317" data-speed="1000"></span>
                                <b>명</b>
                            </div>
                        </li>
                        <li>
                            <img src="img/sell.png" alt="sell">
                            <p>금일 판매량</p>
                            <div class="number">
                                <span class="timer count-title count-number" data-to="1220" data-speed="1000"></span>
                                <b>개</b>
                            </div>
                        </li>
                        <li>
                            <img src="img/graph.png" alt="graph">
                            <p>누적 판매량</p>
                            <div class="number">
                                <span class="timer count-title count-number" data-to="122520" data-speed="1000"></span>
                                <b>개</b>
                            </div>
                        </li>
                        <li>
                            <img src="img/news.png" alt="news">
                            <p>최신 관련 기사</p>
                            <div class="number">
                                <span class="timer count-title count-number" data-to="5" data-speed="1000"></span> 
                                <b>개</b>                           
                            </div>
                        </li>
                    </ul>
                </div>
            </div>
        </section>
        <section class="sec6 scrollSet">
            <div class="center">
                <div class="con ani firstAni">
                <p>Content</p>
                <h2><b>온라인 문의</b>를 통해 <br>간편하게 문의해보세요.</h2>
                <h3>입력해주신 정보는 저장되거나 공개되지 <br> 않으며 ,
                담당자 이메일로 발송됩니다.</h3>
            </div>
                <div class="name ani firstAni">
                    <p>이름*</p>
                    <p>개인정보처리방침*</p>
                    <p>이메일*</p>
                    <p>연락처*</p>
                </div>
                <div class="mail ani secondAni">
                    <p>문의사항(1000자 이내)</p>
                </div>
                <div class="fot ani">
                    <p>개인정보처리방침 에 동의합니다. <button>가입하기</button> </p>
                </div>
            </div>
        </section>
        <!-- footer include -->
        <?php include "footer.php"; ?>
    </div>
    <!-- top include -->
    <?php include "top.php"; ?>
    <script>
        //sec5 영역의 count animation
        (function ($) {
  $.fn.countTo = function (options) {
    options = options || {};
    
    return $(this).each(function () {
      // set options for current element
      var settings = $.extend({}, $.fn.countTo.defaults, {
        from:            $(this).data('from'),
        to:              $(this).data('to'),
        speed:           $(this).data('speed'),
        refreshInterval: $(this).data('refresh-interval'),
        decimals:        $(this).data('decimals')
      }, options);
      
      // how many times to update the value, and how much to increment the value on each update
      var loops = Math.ceil(settings.speed / settings.refreshInterval),
        increment = (settings.to - settings.from) / loops;
      
      // references & variables that will change with each update
      var self = this,
        $self = $(this),
        loopCount = 0,
        value = settings.from,
        data = $self.data('countTo') || {};
      
      $self.data('countTo', data);
      
      // if an existing interval can be found, clear it first
      if (data.interval) {
        clearInterval(data.interval);
      }
      data.interval = setInterval(updateTimer, settings.refreshInterval);
      
      // initialize the element with the starting value
      render(value);
      
      function updateTimer() {
        value += increment;
        loopCount++;
        
        render(value);
        
        if (typeof(settings.onUpdate) == 'function') {
          settings.onUpdate.call(self, value);
        }
        
        if (loopCount >= loops) {
          // remove the interval
          $self.removeData('countTo');
          clearInterval(data.interval);
          value = settings.to;
          
          if (typeof(settings.onComplete) == 'function') {
            settings.onComplete.call(self, value);
          }
        }
      }
      
      function render(value) {
        var formattedValue = settings.formatter.call(self, value, settings);
        $self.html(formattedValue);
      }
    });
  };
  
  $.fn.countTo.defaults = {
    from: 0,               // the number the element should start at
    to: 0,                 // the number the element should end at
    speed: 1000,           // how long it should take to count between the target numbers
    refreshInterval: 1,  // how often the element should be updated
    decimals: 0,           // the number of decimal places to show
    formatter: formatter,  // handler for formatting the value before rendering
    onUpdate: null,        // callback method for every time the element is updated
    onComplete: null       // callback method for when the element finishes updating
  };
  
  function formatter(value, settings) {
    return value.toFixed(settings.decimals);
  }
}(jQuery));

jQuery(function ($) {
  // custom formatting example
  $('.count-number').data('countToOptions', {
  formatter: function (value, options) {
    return value.toFixed(options.decimals).replace(/\B(?=(?:\d{3})+(?!\d))/g, ',');
  }
  });
  
  // start all the timers
  $('.timer').each(count);  
  
  function count(options) {
  var $this = $(this);
  options = $.extend({}, options || {}, $this.data('countToOptions') || {});
  $this.countTo(options);
  }
});
    </script>
</body>
</html>