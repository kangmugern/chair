<div class="top">
        <a href="#">
            <img src="img/up_arrow.png" alt="arrow">
        </a>
    </div>