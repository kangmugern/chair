<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0 , maximum-scale=1.0 , minimum-scale=1.0">
    <title>Procuct</title>
    <!-- 파비콘 -->
    <link rel="shortcut icon" href="img/favicon.png">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@10/swiper-bundle.min.css"/>
    <script src="https://cdn.jsdelivr.net/npm/swiper@10/swiper-bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/swiper@10/swiper-bundle.min.js"></script>
    <!-- 사용자 정의 css 연결 -->
    <link rel="stylesheet" href="css/main.css" type="text/css">
    <link rel="stylesheet" href="css/sub.css" type="text/css">
    <!-- 제이쿼리 라이브러리 연걸 -->
    <script src="js/jquery-3.7.1.js"></script>
    <!-- 사용자 정의 제이쿼리 파일 연동 -->
    <script src="js/main.js"></script>
</head>
<body>
    <div class="wrap">
     <!-- header include -->
    <?php include "header.php" ;?>

    <section class="subMain">
        <div><h1>디자인 & 필라소피</h1></div>
    </section>
    <section class="product">
        <div class="center">
        <div class="pro1">
            <div class="photo"></div>
                <div class="des">
                    <h1>Task chair</h1>
                    <h2>MODERN</h2>
                    <div class="des1">
                        <h4>모던</h4>
                        <p>편안함은 물론 간결한 디자인으로 집 , 사무실 등 어떠한 환경에도 잘 어울립니다.</p>
                    </div>
                    <div class="des2">
                        <h4>인체공학적 싱크로나이즈드 틸팅</h4>
                        <p>몸을 뒤로 젖힐 때 등판과 좌판이 각기 다른 각도로 움직여 틸팅시 대퇴부의 압박 없이 편안함을 유지합니다.</p>
                    </div>
                    <div class="des3">
                        <h4>좌판 길치 조절</h4>
                        <p>좌판 깊이 조절로 다양한 체형의 사람들 모두 편안한 사용이 가능합니다.</p>
                    </div>
                </div>
        </div>
        <div class="pro2">
            <div class="photo"></div>
            <div class="des">
                <h1>Multi chair</h1>
                <h2>STOA SWIVEL</h2>
                <div class="des1">
                    <h4>스토아</h4>
                    <p>인체공학적인 형태로 간결하지만 최상의 편안함을 느낄 수 있는 의자입니다. 공간차지가 적은 장점이 있습니다.</p>
                </div>
                <div class="des2">
                    <h4>조절형 헤드레스트</h4>
                    <p>헤드레스트 높이 조절 및 탈부착 가능합니다.
고급 인조가죽 원단을 적용하여 내구성이 좋고 신체에 접촉시 이질감이 적습니다.
                    </p>
                </div>
                <div class="des3">
                    <h4>3D 조절형 팔걸이</h4>
                    <p>높이/깊이/각도 조절 기능으로 다양하며 체형의 사람들 모두 편안한 사용이 가능합니다.</p>
                </div>
            </div>
        </div>
        <div class="pro3">
            <div class="photo"></div>
            <div class="des">
                <h1>Task chair</h1>
                <h2>NATURE</h2>
                <div class="des1">
                    <h4>네이쳐</h4>
                    <p>네이쳐는 나무를 닮은 디자인으로 집 , 사무실 등 어떠한 환경에도 잘 어울립니다.</p>
                </div>
                <div class="des2">
                    <h4>인체공학적 C커프</h4>
                    <p>나뭇잎 요추 지지대는 사람의 중심축이 되는 척추 부위에 C커브를 두어 척추를 건듣리지 않으면서 허리를 부드럽게 지지해 줍니다.</p>
                </div>
                <div class="des3">
                    <h4>좌판 깊이 조절</h4>
                    <p>좌판 깊이 조절로 다양한 체형의 사람들 모두 편안한 사용이 가능합니다.</p>
                </div>
            </div>
        </div>
        <div class="pro4">
            <div class="photo"></div>
            <div class="des">
                <h1>Multi chair</h1>
                <h2>STOA EDUCATION</h2>
                <div class="des1">
                    <h4>스토아 수강용 </h4>
                    <p>스토아는 인체공학적인 형태로 간결하지만 최상의 편안함 느낄 수 있는 의자입니다.</p>
                </div>
                <div class="des2">
                    <h4>일체형 테이블</h4>
                    <p>자유롭게 회전하며 하단부에는 텀블러, 가방 등을 수 납할 수 있습니다.</p>
                </div>
                <div class="des3">
                    <h4>수납공간</h4>
                    <p>가방 등 짐을 놓을 수 있습니다.</p>
                </div>
            </div>
        </div>
        </div>
    </section>

    <!-- footer include -->
    <?php include "footer.php" ;?>
    </div>
    <!-- top include -->
    <?php include "top.php" ;?>
</body>
</html>